# Grpc.Auth

`Grpc.Auth` is the gRPC C#/.NET authentication library based on `Google.Apis.Auth`