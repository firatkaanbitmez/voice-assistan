﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Text.RegularExpressions;
using System.Globalization;

namespace VoiceAssistantApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SpeechRecognitionEngine reco = new SpeechRecognitionEngine();
        SpeechSynthesizer synth = new SpeechSynthesizer();



        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (InstalledVoice voice in synth.GetInstalledVoices())
            {
                VoiceInfo info = voice.VoiceInfo;

                // Find a female voice
                if (info.Gender == VoiceGender.Female)
                {
                    synth.SelectVoice(info.Name);
                    break;
                }
            }



            Voicer();



        }


        private void SpeechRecognitionEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            // Update form with recognized text
            textBox1.Text += e.Result.Text + Environment.NewLine;
        }

        void Voicer()
        {
            string[] commands = { "Opera", "Emma", "Müzik" };
            Choices choices = new Choices(commands);
            Grammar grammer = new Grammar(new GrammarBuilder(choices));
            reco.LoadGrammar(grammer); ///bilgisayarını türkçe değilse hata verir
            reco.SetInputToDefaultAudioDevice();
            reco.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(SpeechRecognitionEngine_SpeechRecognized);

            reco.RecognizeAsync(RecognizeMode.Multiple);
            reco.SpeechRecognized += voicematch;
        }

        private void voicematch(object sender, SpeechRecognizedEventArgs e)
        {
            string text = e.Result.Text.ToLower();

            string operaPattern = @".*\b(opera)\b.*";
            string emmaPattern = @".*\b(emma)\b.*";
            string musicPattern = @".*\b(müzik|music)\b.*";
            string sarkiPattern = @".*\b(şarkı|sarki)\b.*";
            string saatPattern = @".*\b(zaman)\b.*";
            string havaPattern = @".*\b(hava)\b.*";

            if (Regex.IsMatch(text, operaPattern))
            {
                System.Diagnostics.Process.Start("C:\\Users\\FIRAT\\AppData\\Local\\Programs\\Opera GX\\launcher.exe");
            }
            if (Regex.IsMatch(text, emmaPattern))
            {
                synth.SpeakAsync("Efendim?");
            }
            if (Regex.IsMatch(text, musicPattern))
            {
                synth.SpeakAsync("Tabii, ne tür müzik çalmamı istersiniz?");
            }
            if (Regex.IsMatch(text, sarkiPattern))
            {
                synth.SpeakAsync("Evet, ne tür bir şarkı istersiniz?");
            }
            if (Regex.IsMatch(text, saatPattern))
            {
                DateTime now = DateTime.Now;
                string time = "Şu an saat " + now.ToString("h:mm tt") + ".";
                synth.SpeakAsync(time);
            }
            if (Regex.IsMatch(text, havaPattern))
            {
                synth.SpeakAsync("Maalesef hava durumunu öğrenmek için internet bağlantınızın olması gerekiyor.");
            }
        }
    }
}